import { combineReducers } from 'redux'

const loginState = (state = {
    // 名字
    name: 'qiqi',
    // 是否登录
    isLogin: false
}, action) => {
    switch (action.type) {
        case 'login':
            return {
                ...state,
                isLogin: true
            };
        case 'logout':
            return {
                ...state,
                isLogin: false
            };
        default:
            return state
    }
}


export default combineReducers({
    'login': loginState
})

