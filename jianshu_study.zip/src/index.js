import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
// 如果是做一个SPA 项目，就一定要引用 路由，
import { BrowserRouter, HashRouter } from 'react-router-dom'
import * as serviceWorker from './serviceWorker';
import 'antd/dist/antd.css'; // or 'antd/dist/antd.less'
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import reducer from './store/reducer'

/**
 * 第一个参数： reducer
 * 第二个参数： state 数据
 * 第三个参数: 插件
 */
var store = createStore(reducer)

ReactDOM.render(
    <Provider store={store}>
        {/*放在根节点的目的是路由对所有的组件都有效 */}
        <BrowserRouter>
            <App />
        </BrowserRouter>
    </Provider>
    , document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
