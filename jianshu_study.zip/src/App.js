import React, { Component } from 'react'
import {BrowserRouter, Switch, Route, Redirect} from 'react-router-dom'
// import {HomePage} from './pages/HomePage'
import HomePage from './pages/HomePage'
import LoginPage from './pages/LoginPage'

export default class App extends Component {
  constructor (props) {
    super(props)
  }

  render() {
    return (
        <Switch>
          {/* 因为 HomePage 组件下面存在子路由，所以不能用 exact */}
          <Route path='/home' component={HomePage}></Route>
          <Route path='/login' component={LoginPage}></Route>
          {/* 如果没有一个匹配，就直接跳转到 /home地址 */}
          <Redirect to='/home'></Redirect>
        </Switch>
    )
  }
}
