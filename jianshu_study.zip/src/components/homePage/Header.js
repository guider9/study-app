import React, { Component } from 'react'
import PropTypes from 'prop-types'
import styleObj from './Header.module.scss'
import { Link } from 'react-router-dom'
import { Icon } from 'antd';
// import 一定要在定义变量之前，即imoport 一定要放在最前面
import { HeaderSearch } from './HeaderSearch'
import { connect } from 'react-redux'

export class Header extends Component {
    static propTypes = {

    }

    constructor (props) {
        super(props)
    }

    render() {
        let {isLogin, logoutAction} = this.props;
        return (
            <div className={styleObj['header-page']}>
                <div className={styleObj['left-nav']}>
                    <Link to="" className={styleObj['logo']}>logo</Link>
                    <Link to="" className={styleObj['go-home']}>首页</Link>
                    <Link to="/home/detail" className={styleObj['download-app']}>下载App</Link>
                    {/* 头部的搜索框 */}
                    <HeaderSearch />
                </div>
                <div className={styleObj['right-nav']}>
                    <Link to="" className={styleObj.Aa}>Aa</Link>
                    {
                        isLogin?
                        (<Link onClick={logoutAction} className={styleObj['go-login']}>退出--{isLogin+''}</Link>)
                        :
                        (<Link to="/login" className={styleObj['go-login']}>登录--{isLogin+''}</Link>)
                    }
                    
                    <Link to="" className={styleObj['go-register']}>注册</Link>
                    <Link to="/home/editor" className={styleObj['go-writearticle']}><Icon type="edit" />写文章</Link>
                </div>
            </div>
        )
    }
}


// 将store 中的state映射为 UI组件的props，即，给UI组件添加数据
function mapStateToProps(state) {
    return {
        isLogin: state.login.isLogin
    }
}

// 给UI组件的props添加含有 dispatch 参数的方法,即，给UI组件传入方法
function mapDispatchToProps(dispatch) {
    return {
        logoutAction: function () {
            dispatch({
                type: 'logout'
            })
        }
    }
}

const HeaderConn = connect(mapStateToProps, mapDispatchToProps)(Header);

export default HeaderConn;
