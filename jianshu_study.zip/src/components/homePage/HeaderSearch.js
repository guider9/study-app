import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { Input, Icon, Popover } from 'antd';
import styleObj from './HeaderSearch.module.scss'
const { Search } = Input;

export class HeaderSearch extends Component {
    static propTypes = {

    }

    constructor(props) {
        super(props);
        this.state = {
            data: ['PPT','职场','大数据','创业','书评','东风','程序员']
        }
    }

    getSearchTipsHtml = () => {
        // 查询给出他提示数据
        const {data} = this.state;
        const content = (
            <div className={styleObj['search-list']}  ref={this.listRef} > 
                <div className={styleObj['search-top']}>
                    <span className={styleObj['search-title']}>热门搜索</span>
                    <span className={styleObj['search-change']}>换一批</span>
                </div>
                <ul className={styleObj['searchul']}>
                    {
                        data.map((item,index)=>{
                            return (
                                // 循环data
                                <li className={styleObj['search-item']} key={index}>{item}</li>
                            )
                        })
                    }
                </ul>
            </div>
        );
        return content;
    }

    render() {
        
        // 弹出提示框的HTML 代码
        const contentHtml = this.getSearchTipsHtml();
        return (
            <>
                <Popover content={contentHtml}  trigger="click">
                    <Search
                        style={{ width: "240px" }}
                        placeholder="搜索"
                        onSearch={value => console.log(value)}
                        style={{ width: 200 }}
                    />
                </Popover>
            </>
        )
    }
}

export default HeaderSearch
