import React from "react";
import articleDetailObj from "./ArticleDetail.module.scss";
import axios from 'axios'


export default class articleDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
        // 把文章对象的字段属性 描述出来，方便理解
        articleObj : {
            title: '',
            imgUrl: '',
            desc: ''
        }
    }
  }

  componentDidMount= () => {
      const that = this;
      var articleId = this.props.match.params.id;
      // 如果没有 articleId 则重定向到首页
      if (articleId === undefined || articleId === null || articleId === '') {
          this.props.history.push('/home')
        //   this.props.history.push({
        //       pathname: '/home'
        //   })
      } else {
          axios.get('/data/homePage/DetailDataArr.json')
          .then(function (res){
              var serverDataArr = res.data;
              var arrIndex = parseFloat(articleId)-1;
              var detailObjData = serverDataArr[arrIndex];
              that.setState({
                articleObj: detailObjData
              })
          })
      }
  }
  
  render() {
    let {articleObj} = this.state;
    return (
      // HTML代码
      <div className={articleDetailObj["articleDetailPage"]}>
        <h3>{articleObj.title}</h3>
        <img
          src={articleObj.imgUrl}
          alt=""
        />
        <p>
            {articleObj.desc}
        </p>
      </div>
    );
  }
}
