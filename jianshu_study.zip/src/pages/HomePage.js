import React, { Component } from 'react'
import Header from '../components/homePage/Header'
import ArticleList  from './ArticleList'
import ArticleDetail  from './ArticleDetail'
import EditorPage  from './EditorPage'
import {Switch, Route, Redirect} from 'react-router-dom'

export class HomePage extends Component {
    static propTypes = {
    }

    constructor(props) {
        super(props)
    }

    render() {
        return (
            <div>
                {/* 头部导航 */}
                <Header></Header>
                {/* 
                    1. 需要把变化的部分，使用 路由来动态切换
                */}
                <Switch>
                    {/* 与父组件的路由一模一样，采用 exact 精确匹配 */}
                    <Route path='/home' exact component={ArticleList}></Route>
                    <Route path='/home/editor'  component={EditorPage}></Route>
                    <Route path='/home/detail/:id'  component={ArticleDetail}></Route>
                    <Redirect from='/home/aaa' to='/home'></Redirect>
                    <Redirect from='/home/detail' to='/home/detail/1'></Redirect>
                    {/* 使用正则表达式匹配路径 */}
                    <Redirect from='/home/*' to='/home/detail/1'></Redirect>
                </Switch>
            </div>
        )
    }
}

export default HomePage
