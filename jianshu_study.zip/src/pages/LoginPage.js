import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { Form, Input, Button } from 'antd'

export class LoginPage extends Component {
    static propTypes = {

    }

    constructor(props) {
        super(props);
        this.formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 8 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 8 },
            },
        };
        this.tailFormItemLayout = {
            wrapperCol: {
                xs: {
                    span: 24,
                    offset: 0,
                },
                sm: {
                    span: 16,
                    offset: 8,
                },
            },
        };
    
        this.state = {
            account: '',
            pwd: ''
        }
    }

    // 登录按钮触发的事件
    loginAction = () => {
        let {account, pwd} = this.state;
        let {loginAction} = this.props;
        if (account == '111' && pwd == '123') {
            loginAction({
                account: account,
                pwd: pwd,
            });
            this.props.history.push({
                pathname: '/home'
            })
        }
    }

    inputChangeAction = (typeStr, eventObj) => {
        var value = eventObj.target.value;
        this.setState({
            [typeStr]: value
        })
    }
    
    render() {
        let { username, isLogin } = this.props;
        let {account, pwd} = this.state;
        return (
            <div>
                <div>
                    {/* {} 表达式是不显示 boolean */}
                    {isLogin+'  OK '}
                </div>
                <Form {...this.formItemLayout}>
                    <Form.Item label="用户名" >
                        <Input value={account} onChange={this.inputChangeAction.bind(this, 'account')}/>
                    </Form.Item>
                    <Form.Item label="密码">
                        <Input.Password  value={pwd} onChange={this.inputChangeAction.bind(this, 'pwd')}/>
                    </Form.Item>

                    <Form.Item {...this.tailFormItemLayout}>
                        <Button type="primary" onClick={this.loginAction}>
                            登录
                        </Button>
                         
                        <Button type="primary" onClick={()=>{this.props.history.push('/home')}}>
                            返回
                        </Button>
                    </Form.Item>
                </Form>
            </div>
        )
    }
}

// 将store 中的state映射为 UI组件的props，即，给UI组件添加数据
function mapStateToProps(state) {
    return {
        username: state.login.name,
        isLogin: state.login.isLogin
    }
}

// 给UI组件的props添加含有 dispatch 参数的方法,即，给UI组件传入方法
function mapDispatchToProps(dispatch) {
    return {
        loginAction: function (uerInputObj) {
            dispatch({
                type: 'login',
                userInputObj: uerInputObj,
                'who': 'naoteng',
                'age': 18
            })
        }
    }
}

const LoginPageConn = connect(mapStateToProps, mapDispatchToProps)(LoginPage);

export default LoginPageConn;

