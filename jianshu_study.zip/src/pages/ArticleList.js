import React from 'react';
import styleObj from './ArticleList.module.scss'
// 引用模拟的数据
// import articleListArr from '../data/homePage/ArticleListArr'
import axios from 'axios'
import {Link} from 'react-router-dom'

export class ArticleList extends React.Component {
    constructor(props) {
        super(props);
        // console.log(articleListArr);
        // debugger
        this.state = {
            //轮播图数据
            bannerpic: [],
            //选项数据
            otherItem: [],
            //文章列表数据
            articleList: []
        }
        this.getArticleListHtmlByData = this.getArticleListHtmlByData.bind(this)
    }

    componentDidMount = () => {
        let that = this;
        // require 是引入的模块，即 JSON 对象
        // var dataUrl = require('http://localhost:3000/public/ArticleListArr.json');
        // create-react-app 脚手架会自动把 public 下面的所有文件全部复制
        // var dataUrl = 'http://localhost:3000/data/homePage/ArticleListArr.json';
        var dataUrl = '/data/homePage/ArticleListArr.json';
        console.log(dataUrl);
        axios.get(dataUrl)
        .then(function (res) {
            console.log(res);
            that.setState({
                articleList: res.data.data
            })
        })
    }

    // 根据后台的数据显示 list 列表的 html
    getArticleListHtmlByData = () => {
        let {articleList} = this.state
        var  articleListHtml = articleList.map(function (articleObj, index) {
            return (
                <div key={index} className={styleObj["articles-item"]}>
                    {/* 1. a 标签默认会让浏览器刷新，所以要阻止默认行为
                    2. 为了兼容各种模式，所以建议使用 Link */}
                    {/* <a href="/home/detail"> */}
                    <Link to={'/home/detail/'+articleObj.id}>
                        <div className={styleObj["articles-text"]}>
                            <h3>{articleObj.title}</h3>
                            <p>{articleObj.desc}</p>
                        </div>
                    </Link>
                    {/* </a> */}
                </div>
            )
        })
        return articleListHtml;
    }

    render() {
        // 根据后台的数据显示 list 列表的 html
        var articleListHtml = this.getArticleListHtmlByData();
        return (
            <div className={styleObj['main']}>
                <div className={styleObj["main-inner"]}>
                    <div className={styleObj["banner"]}>
                        {/* 引用静态图片需要使用require */}
                        <img src={require('../asserts/images/bannerpic.jpg')} alt="" />
                    </div>
                    <div className={styleObj["other"]}>
                        <div className={styleObj["other-item"]}>
                            <img src={require('../asserts/images/otherpic1.jpg')} alt="" /> 社会热点
                        </div>
                        <div className={styleObj["other-item"]}>
                            <img src={require('../asserts/images/otherpic2.jpg')} alt="" /> 社会热点
                        </div>
                    </div>
                    <div className={styleObj["articles-list"]}>
                        {/* 不要在render函数里面写逻辑， */}
                        {articleListHtml}
                    </div>
                    <div className={styleObj["more"]}>更多文字</div>
                </div>
            </div>
        )
    }

}

export default ArticleList;


