import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'

export class EditorPage extends Component {
    static propTypes = {

    }

    constructor(props) {
        super(props)
        this.state = {
             
        }
    }

    componentWillMount = () => {
        let {isLogin} = this.props;
        if (!isLogin) {
            this.props.history.push('/login')
        }
    }
    

    render() {
        let {isLogin} = this.props;
        return (
            <div>
                EditorPage ---- {isLogin+''}
            </div>
        )
    }
}

// mapStateToProps = (state) => {
function mapStateToProps(state) {    
    return {
        isLogin: state.login.isLogin
    }
}

const EditorPageConn = connect(mapStateToProps)(EditorPage)
export default EditorPageConn;